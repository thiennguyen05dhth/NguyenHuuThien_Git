- Be noted that Bootstrap Studio is a software which works through internet and it won't work without an internet connection.

- Other than just install and do not update it.