========================================================
Pixie v3.1         
Nattyware, Jul 17, 2003
========================================================

To whom it is the first time: introducing Pixie - the
colour picker that will let you feel the colours. For 
those, who are using Pixie already -  thank you and 
there is the list of new features since the previous 
release:

[+] "Freeze" mode added.
[+] Hotkeys redefine feature added.

Please read the documentation for details.

The latest version of Pixie can always be found on Web 
site at http://www.nattyware.com
